package com.tata.ecommerce.utility;

import com.tata.ecommerce.business.TaxCalculator;
import com.tata.ecommerce.business.TaxCalculatorImpl;
import com.tata.ecommerce.models.Category;
import com.tata.ecommerce.models.Product;

import java.time.LocalDate;
import java.util.Random;
import java.util.Scanner;

public class OrderApp {

    public static void main(String[] args){

         //to read data from keyboard
        Scanner scanner=new Scanner(System.in);
        //read category related data
        //constructor and instantiation
        //default constructor
        Category category=new Category();
        //auto generated
        category.setCategoryId(new Random().nextInt(10000));
        //assign the name
       System.out.println("Enter Category Name");
        category.setName(scanner.nextLine());
        System.out.println(category);

        //read product related data

        Product product=new Product();
        product.setProductId(new Random().nextInt(10000));
        product.setCategory(category);
        product.setAvailableQty(new Random().nextInt(1000));
        System.out.println("Enter Product Name");
        product.setProductName(scanner.nextLine());
        product.setCost(new Random().nextInt(10000));
        product.setDop(LocalDate.now());
        product.setGst(false);

        //tax calculation
        //run time polymorphism
        TaxCalculator taxCalculator=new TaxCalculatorImpl();
        if(product.isGst())
           System.out.println("GST Value"+
                   taxCalculator.computeIGST(product.getCost()*5,
                           product.getCategory().getName()));
        else
        {
          for(float tax:  taxCalculator.computeCGSTSGST(product.getCost()*5,
                    product.getCategory().getName())){
             System.out.print(tax+",");
        }
        }



    }

}
