package com.tata.ecommerce.utility;

import com.tata.ecommerce.models.Customer;
import com.tata.ecommerce.models.Employee;
import com.tata.ecommerce.models.Person;

public class UserApp {



    public static void main(String... args){
      Customer customer1=new Customer();
      customer1.setName("Parameswari");
        Customer customer2=new Customer();
        customer2.setName("Parameswari");
        System.out.println(customer1.equals(customer2));

    }
}
