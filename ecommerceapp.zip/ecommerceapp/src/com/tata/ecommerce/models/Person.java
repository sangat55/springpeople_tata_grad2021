package com.tata.ecommerce.models;

public class Person {
    protected String adharCardNo;
    protected String name;
    //has relationship
    protected Address address;
    protected long mobileNo;

    public String getAdharCardNo() {
        return adharCardNo;
    }

    public void setAdharCardNo(String adharCardNo) {
        this.adharCardNo = adharCardNo;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public long getMobileNo() {
        return mobileNo;
    }

    public void setMobileNo(long mobileNo) {
        this.mobileNo = mobileNo;
    }

    @Override
    public String toString() {
        return "Person{" +
                "adharCardNo='" + adharCardNo + '\'' +
                ", name='" + name + '\'' +
                ", address=" + address +
                ", mobileNo=" + mobileNo +
                '}';
    }
}
