package com.tata.ecommerce.models;

public enum CustomerType {
    Guest,Prime,Express
}
