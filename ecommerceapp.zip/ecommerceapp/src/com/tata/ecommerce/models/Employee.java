package com.tata.ecommerce.models;
//is relationship with person
public class Employee extends Person{

    private long employeeId;
    //has relationship
    private Project project;
    private String location;

    public long getEmployeeId() {
        return employeeId;
    }

    public void setEmployeeId(long employeeId) {
        this.employeeId = employeeId;
    }

    public Project getProject() {
        return project;
    }

    public void setProject(Project project) {
        this.project = project;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    @Override
    public String toString() {
        return "Employee{" +
                "employeeId=" + employeeId +
                ", project=" + project +
                ", location='" + location + '\'' +
                ", adharCardNo='" + adharCardNo + '\'' +
                ", name='" + name + '\'' +
                ", address=" + address +
                ", mobileNo=" + mobileNo +
                '}';
    }
}
