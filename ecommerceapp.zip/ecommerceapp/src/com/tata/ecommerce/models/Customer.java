package com.tata.ecommerce.models;
//is relationship with person
public class Customer extends Person {
    //has relationship
    private CustomerType customerType;
    //has relationship
    private Card card;

    @Override
    public int hashCode() {
        return super.hashCode();
    }

    @Override
    public boolean equals(Object obj) {
        Customer customer= (Customer) obj;
        return this.name.equals(customer.name);
    }

    @Override
    public String toString() {
        return "Customer{" +
                "customerType=" + customerType +
                ", card=" + card +
                ", adharCardNo='" + adharCardNo + '\'' +
                ", name='" + name + '\'' +
                ", address=" + address +
                ", mobileNo=" + mobileNo +
                '}';
    }

    public Card getCard() {
        return card;
    }

    public void setCard(Card card) {
        this.card = card;
    }

    public CustomerType getCustomerType() {
        return customerType;
    }

    public void setCustomerType(CustomerType customerType) {
        this.customerType = customerType;
    }

}
