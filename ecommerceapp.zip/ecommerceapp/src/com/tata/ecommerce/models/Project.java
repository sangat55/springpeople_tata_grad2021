package com.tata.ecommerce.models;

public class Project {
    private long projectCode;
    private String name;
    private String client;

    public long getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(long projectCode) {
        this.projectCode = projectCode;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getClient() {
        return client;
    }

    public void setClient(String client) {
        this.client = client;
    }

    @Override
    public String toString() {
        return "Project{" +
                "projectCode=" + projectCode +
                ", name='" + name + '\'' +
                ", client='" + client + '\'' +
                '}';
    }
}
